//
//  AddStockProtocol.swift
//  StockTickerExample
//
//  Created by Ashish on 2/19/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

protocol AddStockProtocol{
    
    func SendStockSymbol(symbol: String)
    
}
