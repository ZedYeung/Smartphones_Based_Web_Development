//
//  WeatherModel.swift
//  SeattleWeatherApp
//
//  Created by Ashish on 2/13/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

class WeatherModel{
    
    var temperature: Int = 0
    var weatherCondition: String = ""
    var cityName : String = ""
    
}
