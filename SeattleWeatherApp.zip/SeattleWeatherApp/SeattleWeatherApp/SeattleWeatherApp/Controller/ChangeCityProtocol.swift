//
//  ChangeCityProtocol.swift
//  SeattleWeatherApp
//
//  Created by Ashish on 2/13/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

protocol ChangeCityProtocol{
    func ChangeCityFunction(cityName: String)
}
